# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Cauchy-Schott-My"
equation      = r"sqrt(1 + A*(x^2)/(x^2-D) + B*(x^2)/(x^2-E))"
latexequation = r"\sqrt{1 + Ax^2/(x^2-D) + Bx^2/(x^2-E)}"
description   = "???"
reference     = "???"

def evaluate(x,a,c,b,k,f,g,h):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return sqrt(a+(c*x**2)+(exp(b/x**2))+(exp(k*x**2))+(f*x**4)+(g/x**6)+(h/x**8))   #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   a = 0.2
   c = 0.05
   b = 0.01
   k = -0.05
   f = -0.001
   g = 0.001
   h = 0.001
   
   
   return a,c,b,k,f,g,h     # return the parameters back to the caller.

