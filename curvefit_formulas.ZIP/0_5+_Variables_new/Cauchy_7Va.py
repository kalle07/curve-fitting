# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Cauchy_7Va"
equation      = r"sqrt(A+(BE-3*x**2)-(CE-3*x**4)+(DE-2*x**-2)-(FE-3*x**-4)+(GE-4*x**-6)-(HE-5*x**-8))"
latexequation = r"\sqrt{(A+(BE-3*x**2)-(CE-3*x**4)+(DE-2*x**-2)-(FE-3*x**-4)+(GE-4*x**-6)-(HE-5*x**-8))}"
description   = "???"
reference     = "???"

def evaluate(x,A,B,C,D,F,G,H):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return sqrt (A+(B*x**2)-(C*x**4)+(D*x**-2)-(F*x**-4)+(G*x**-6)-(H*x**-8))   #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   A = 2.2
   B = -0.001
   C = -1.0e-4
   D = 0.01
   F = -1.0e-4
   G = -2.0e-6
   H = -2.0e-7
 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return A,B,C,D,F,G,H     # return the parameters back to the caller.

