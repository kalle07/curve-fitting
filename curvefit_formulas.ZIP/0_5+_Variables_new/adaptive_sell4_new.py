# py3
import numpy as np

name = r"adapt4"
equation = r"n+A*(x-x0)+B*(x-x0)**2+C*(x-x0)**3+(D*(x-x0)**4/(1+k*(x-x0)))"
latexequation = r"n+A*(x-x_0)+B*(x-x_0)^2+C*(x-x_0)^3+(D*(x-x_0)^4/(1+k*(x-x_0)))"

def evaluate(x, A, B, C, D, k, x0):
    """
    The evaluate function determines the function itself. It takes an x value and current parameters
    as an argument, and returns the function evaluation.
    """
    n = 1.50115
    return n + A * (x - x0) + B * (x - x0) ** 2 + C * (x - x0) ** 3 + (D * (x - x0) ** 4) / (1 + k * (x - x0))

def initialize(x, y):
    """
    The initialize function is in charge of initializing the parameters, given the raw data
    x and y (which are columns of data). Any Python functions can be used here.
    The return value from this function should be anything that can be translated into
    a numpy array. If you don't know what this means, don't worry; just follow the
    examples.
    """
    # Find valid values of x and y
    flags = np.logical_and(x > 0.0, y > 0.0)
    x = x[flags]
    y = y[flags]
    
    # Set initial parameter values
    A = np.random.uniform(-1, 2.0)
    B = np.random.uniform(0.01, 2.5)
    C = np.random.uniform(-0.5, 2.0)
    D = np.random.uniform(0.01, 2.0)
    k = np.random.uniform(0.0, 1.0)
    x0 = np.random.uniform(x.min(), x.max())
    
    return A, B, C, D, k, x0  # Return the parameters back to the caller.
