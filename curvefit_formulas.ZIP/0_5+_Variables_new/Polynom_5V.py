# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Polynom 5V"
equation      = r"(1.2+c*x**2)/(1+b*x**2+d*x**4*e/10*x**6)"
latexequation = r"\frac{1.2+c*x**2}{1+b*x**2+d*x**4*e/10*x**6}"
description   = "???"
reference     = "???"

def evaluate(x,a,b,c,d,e):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return (1.2+c*x**2)/(1+b*x**2+d*x**4*e/10*x**6)   #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   a = 1.0
   b = -100 #0.05
   c = -100 #-0.3
   d = -0.1 #-0.01
   e = -0.005
   

 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return a,b,c,d,e   # return the parameters back to the caller.

