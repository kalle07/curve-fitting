# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"adaptive_Sellmeier6V3_new"
equation      = r"n+A*(x-x0)+B*(x-x0)**2+C*(x-x0)**3+(D*(x-x0)**4/(1+k*(x-x0)))"
latexequation = r"n+A*(x-x0)+B*(x-x0)**2+C*(x-x0)**3+(D*(x-x0)**4/(1+k*(x-x0)))"
description   = "???"
reference     = "???"

def evaluate(x,n,A,B,C,D,k,x0):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   n=1.51
   x0=1.50115
   return n+A*(x-x0)+B*(x-x0)**2+C*(x-x0)**3+(D*(x-x0)**4/(1+k*(x-x0)))  #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   A = -0.02
   B = 0.01
   C = -0.02
   D = 0.02
   k = 0.5
   # x0 mittig zwischen 0.3 und 2.55
   # besser n=1.55 einzutragen gemessen bei zB 0.63nm=x0 (Term x-x0)
   
   return A,B,C,D,k     # return the parameters back to the caller.

