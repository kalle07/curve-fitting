# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"adaptive_Sellmeier6VA"
equation      = r"n+A*(x-1.145)+B*(x-1.145)**2+C*(x-1.145)**3+(D*(x-1.145)**4/(1+k*(x-1.145)))"
latexequation = r"n+A*(x-1.145)+B*(x-1.145)**2+C*(x-1.145)**3+(D*(x-1.145)**4/(1+k*(x-1.145)))"
description   = "???"
reference     = "???"

def evaluate(x,n,A,B,C,D,k):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return n+A*(x-1.145)+B*(x-1.145)**2+C*(x-1.145)**3+(D*(x-1.145)**4/(1+k*(x-1.145)))  #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   n = 0.001
   A = -0.01
   B = 0.005
   C = 0.001
   D = 0.001
   k = 1.0
   # 1.145 mittig zwischen 0.4 und 1.55
   
   return n,A,B,C,D,k     # return the parameters back to the caller.

