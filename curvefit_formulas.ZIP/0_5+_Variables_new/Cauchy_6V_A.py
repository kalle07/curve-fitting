# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Cauchy_6V_A"
equation      = r"sqrt (A+(B*x**2)+(C*x**-2)+(D*x**-4)+(F*x**-5)+(G*x**-6))"
latexequation = r"\sqrt{(A+(B*x**2)+(C*x**-2)+(D*x**-4)+(F*x**-5)+(G*x**-6))}"
description   = "???"
reference     = "???"

def evaluate(x,A,B,C,D,F,G):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return sqrt (A+(B*x**2)+(C*x**-2)+(D*x**-4)+(F*x**-5)+(G*x**-6))   #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   A = 2.0 #3 5.0
   B = -0.01 #3 0.05
   C = 0.01 #3 0.1
   D = 0.002 #2 0.0001 #3 0.01
   F = -0.002 #2 -0.0001 #3 -0.005
   G = 0.0001 #2 0.000001 #3 0.002
    #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return A,B,C,D,F,G     # return the parameters back to the caller.

