# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"5V_Sellmeier_2_EV"
equation      = r"(a+c*x**2+e*x**4)/(1+b*x**2+d*x**4+f*x**6)"
latexequation = r"\frac{a+c*x**2+e*x**4}{1+b*x**2+d*x**4+f*x**6}"
description   = "???"
reference     = "???"

def evaluate(x,A,B,C,D,E):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return sqrt(A+B*x**2/(x**2-C)+D*x**2/(x**2-E))  #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   A = 1.5
   B = 1.0
   C = 0.01
   D = 1.0
   E = 100.0
    

 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return A,B,C,D,E    # return the parameters back to the caller.

