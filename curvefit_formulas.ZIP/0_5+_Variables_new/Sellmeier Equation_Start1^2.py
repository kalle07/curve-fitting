# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Sellmeier Equation_Start1_^2"
equation      = r"sqrt (1 + A*(x**2)/(x**2-D**2) + B*(x**2)/(x**2-E**2)+C*(x**2)/(x**2-F**2))"
latexequation = r"\sqrt{(1 + A*(x**2)/(x**2-D**2) + B*(x**2)/(x**2-E**2)+C*(x**2)/(x**2-F**2))}"
description   = "???"
reference     = "???"

def evaluate(x,A,B,C,D,E,F):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return sqrt (1 + A*(x**2)/(x**2-D**2) + B*(x**2)/(x**2-E**2)+C*(x**2)/(x**2-F**2))   #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   A = 1.0
   B = 0.4
   C = 0.9
   D = 0.07
   E = 0.1
   F = 15.0
   A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 4 
   
   
   return A,B,C,D,E,F     # return the parameters back to the caller.

