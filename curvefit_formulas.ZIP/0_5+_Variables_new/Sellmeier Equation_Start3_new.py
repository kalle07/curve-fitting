# py3
# this preamble is optional, but it makes things nicer. Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name = r"sellmeier_start3_new"
equation = r"\sqrt{1 + A\frac{x^2}{x^2 - D} + B\frac{x^2}{x^2 - E} + C\frac{x^2}{x^2 - F}}"
latexequation = r"\sqrt{1 + \frac{A x^2}{x^2 - D} + \frac{B x^2}{x^2 - E} + \frac{C x^2}{x^2 - F}}"

def evaluate(x, A, B, C, D, E, F):
    """
    The evaluate function determines the function itself. It takes an x value and current parameters
    as an argument, and returns the function evaluation.
    """
    return sqrt(1 + A * x**2 / (x**2 - D) + B * x**2 / (x**2 - E) + C * x**2 / (x**2 - F))

def initialize(x, y):
    """
    The initialize function is in charge of initializing the parameters, given the raw data
    x and y (which are columns of data). Any Python functions can be used here.
    The return value from this function should be anything that can be translated into
    a numpy array. If you don't know what this means, don't worry; just follow the
    examples.
    """
    import numpy as np
    
    # Find valid values of x and y
    flags = np.logical_and(x > 0.0, y > 0.0)
    x = x[flags]
    y = y[flags]
    
    # Set initial parameter values
    A = np.random.uniform(0.2, 2)
    B = np.random.uniform(0.04, 0.5)
    C = np.random.uniform(0.2, 2)
    D = np.random.uniform(0, 0.01)
    E = np.random.uniform(0, 0.5)
    F = np.random.uniform(10, 500)
	
    A = 1.0
    B = 0.2
    C = 1.0
    D = 0.005
    E = 0.02
    F = 100.0
    
    return A, B, C, D, E, F  # Return the parameters back to the caller.