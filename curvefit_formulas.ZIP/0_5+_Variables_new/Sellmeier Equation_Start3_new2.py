# py3
# this preamble is optional, but it makes things nicer. You can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)

name = r"sellemierstart3_new2"
equation = r"\sqrt{1 + \frac{Ax^2}{x^2 - D} + \frac{Bx^2}{x^2 - E} + \frac{Cx^2}{x^2 - F}}"
latexequation = r"\sqrt{1 + \frac{Ax^2}{x^2 - D} + \frac{Bx^2}{x^2 - E} + \frac{Cx^2}{x^2 - F}}"


def evaluate(x, A, B, C, D, E, F):
    """
    The evaluate function determines the function itself. It takes an x value and current parameters
    as an argument, and returns the function evaluation.
    """
    import numpy as np
    return np.sqrt((1 + A * x ** 2 / (x ** 2 - D) + B * x ** 2 / (x ** 2 - E) + C * x ** 2 / (x ** 2 - F)) ** 0.5)


def initialize(x, y):
    """
    The initialize function is in charge of initializing the parameters, given the raw data
    x and y (which are columns of data). Obviously, any Python functions can be used
    here.

    The return value from this function should be anything that can be translated into
    a numpy array. If you don't know what this means, don't worry; just follow the
    examples.
    """
    import numpy

    x = numpy.array(x)
    y = numpy.array(y)

    flags = numpy.logical_and(x > 0.2, x < 2.5)
    x = x[flags]
    y = y[flags]

    A = 1.0
    B = 0.2
    C = 1.0
    D = 0.005
    E = 0.02
    F = 100.0

    return A, B, C, D, E, F  # return the parameters back to the caller.


def bounds():
    """
    This function specifies the optimization bounds for the parameters.
    """
    return [(0, 10), (0, 10), (0, 10), (0, 1), (0, 1), (0, 1000)]


def constraint1(A, B, C):
    return 0.99 - (1 + A + B + C)

def constraint2(D, E, F):
    return (D + E + F) - 1.01

def constraints():
    """
    This function specifies the optimization constraints for the parameters.
    """
    return [{'type': 'ineq', 'fun': constraint1},
            {'type': 'ineq', 'fun': constraint2}]


def callback(xk):
    """
    This function is called by the optimization routine after each iteration.
    """
    print(xk)


def fit(x, y):
    """
    The fit function performs the actual optimization, given the raw data x and y.
    """
    from scipy.optimize import minimize

    # Call the scipy optimization routine
    p0 = initialize(x, y)
    res = minimize(objective, p0, args=(x, y), method='SLSQP', bounds=bounds(),
                   constraints=constraints(), callback=callback)

