# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"herzberg4V"
equation      = r"sqrt(a+b*x**2+c/(x**2-0.01)+d/(x**2-0.01)**2)"
latexequation = r"\sqrt{(a+b*x**2+c/(x**2-0.01)+d/(x**2-0.01)**2)}"
description   = "???"
reference     = "???"

def evaluate(x,a,b,c,d):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return sqrt(a+b*x**2+c/(x**2-0.01)+d/(x**2-0.01)**2)  #@UndefinedVariable
          

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   a = 2.0 #4
   b = -0.01 #-0.02
   c = 0.01 # 0.05
   d = -0.001 #0.001
   #0.01 ist in original 0.028

 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return a,b,c,d    # return the parameters back to the caller.

