# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"4Marx04_V4B"
equation      = r"m*x+b*(1/((b-m/3/x**d)*(b+m/2*x**c)))"
latexequation = r"m*x+b*(1/((b-m/3/x**d)*(b+m/2*x**c)))"
description   = "???"
reference     = "???"

def evaluate(x,k,b,c,s):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return k*exp(b/x**2)+c*exp(-0.0032*x**2)+ s*exp(-0.0032/20*x**4)   #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   k = -0.1
   b = 0.02
   c = 1
   s = 0.3
   
 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return k,b,c,s    # return the parameters back to the caller.

