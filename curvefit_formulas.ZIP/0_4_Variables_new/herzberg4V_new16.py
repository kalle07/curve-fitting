from scipy.optimize import curve_fit
import numpy as np

name = r"herzberg4V_new16"
equation = r"y = sqrt(a + b * x ** 2 + c / (x ** 2 - 0.01) + d / (x ** 2 - 0.01) ** 2)"
latexequation = r"y = \sqrt{a + b x^2 + \frac{c}{x^2 - 0.01} + \frac{d}{(x^2 - 0.01)^2}}"

def evaluate(x, a, b, c, d):
    return np.sqrt(a + b * x ** 2 + c / (x ** 2 - 0.01) + d / (x ** 2 - 0.01) ** 2)

bounds = ([0.2, -0.1, 0.001, -0.01], [1.0, 0.1, 2.0, 0.01])
bounds = [(0.2, 1.0), (-0.1, 0.1), (-0.01, 0.01)]

# Define the data
x = np.array([0.3, 0.432, 0.63, 0.85, 1.026, 1.312, 1.554, 2.016, 2.434])
y = np.array([1.552770263573871, 1.527078429140649, 1.5151856452759, 1.5098401349174289, 1.507143391738333, 1.503558798360447, 1.500601897832236, 1.49426003597419, 1.487256311781262])

# Define the initialization function
def initialize(x, y):
    # Estimate initial parameters
    a = 2.0
    b = -0.01
    c = 0.01
    d = -0.001

    # Define bounds for the parameters
    bounds = ([0.2, -0.1, 0.001, -0.01], [1.0, 0.1, 2.0, 0.01])
    bounds = [(0.2, 1.0), (-0.1, 0.1), (-0.01, 0.01)]	

    # Perform optimization with bounds
    # popt, _ = curve_fit(evaluate, x, y, [a, b, c, d], bounds=bounds)

    return a,b,c,d