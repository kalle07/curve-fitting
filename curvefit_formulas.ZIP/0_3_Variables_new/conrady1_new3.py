# py3
# this preamble is optional, but it makes things nicer. You can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)

import numpy as np
from scipy.optimize import curve_fit

name = "conrady1_new3"
equation = "a+b/x+c/x**3.5"
latexequation = "a+b/x+c/x^{3.5}"
description = "Conrady's equation"
reference = "Conrady, A. (1895). Die photographie der gestirne."

def evaluate(x, a, b, c):
    """
    The evaluate function determines the function itself. It takes an x value and current parameters
    as an argument, and returns the function evaluation.
    """
    return a + b/x + c/x**3.5

def initialize(x, y):
    """
    The initialize function is in charge of initializing the parameters, given the raw data
    x and y (which are columns of data).
    """
    a = 1.5
    b = 0.01
    c = 0.001
    return a, b, c

def optimize(x, y):
    """
    The optimize function is in charge of optimizing the parameters to fit the given data
    x and y (which are columns of data).
    """
    p0 = initialize(x, y)
    bounds = ([0.2, 0.04, 0.2], [2, 0.5, 2])
    params, _ = curve_fit(evaluate, x, y, p0=p0, bounds=bounds)
    return params
