# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"conrady2"
equation      = r"a+b/x+c/x**3.5"
latexequation = r"a+b/x+c/x**3.5"
description   = "???"
reference     = "???"

def evaluate(x,a,b,c):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return a+b/x+c/x**3.5  #@UndefinedVariable
   

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
 
   import numpy as np
   flags = np.logical_and(x > 0.0, y > 0.0)
   x = x[flags]
   y = y[flags]

   # Set initial parameter values
   a = np.random.uniform(0.2, 2)
   b = np.random.uniform(0.04, 0.5)
   c = np.random.uniform(0.2, 2)   
   
   
   

 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return a,b,c    # return the parameters back to the caller.

