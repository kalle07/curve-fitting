# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Marx01_3V"
equation      = r"1/((a-b/x**2)*(a+0.001*x**c)) * (exp(-0.001*x**2))"
latexequation = r"\frac{1}{((a-b/x**2)*(a+0.001*x**c)) * (exp(-0.001*x**2))}"
description   = "???"
reference     = "???"

def evaluate(x,a,b,c):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return   1/((a-b/x**2)*(a+0.001*x**c)) * (exp(-0.001*x**2))   #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   a = 0.8
   b = 0.001
   c = 1.0
 

 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return a,b,c    # return the parameters back to the caller.

