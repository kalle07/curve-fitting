# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Marx04_3V"
equation      = r"(m*x+b)*((1+a/x**2))"
latexequation = r"(m*x+b)*((1+a/x**2))"
description   = "???"
reference     = "???"

def evaluate(x,m,b,a):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return (m*x+b)*((1+a/x**2))  #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   m = 0.001
   b = 1.4
   a = 0.001
   
 #  A > 0.2 and A < 2.0 and B > 0.04 and B < 0.5 and C > 0.2 and C < 2 
   
   
   return m,b,a    # return the parameters back to the caller.

