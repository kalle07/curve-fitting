# this preamble is optional, but it makes things nicer.  Here, you can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)
name          = r"Sellmeier_1Term+A2"
equation      = r"sqrt(A+(0.2*x**2)/((x**2)-C**2))"
latexequation = r"\sqrt{(A+(0.2*x**2)/((x**2)-C**2))}"
description   = "???"
reference     = "???"

def evaluate(x,A,B,C):
   """
   The evaluate function determines the function itself.  It takes an x value and current parameters
   as an argument, and returns the function evaluation.
   """
   return sqrt (A+(0.2*x**2)/((x**2)-C**2))  #@UndefinedVariable

def initialize(x,y):
   """
   The initialize function is in charge of initializing the parameters, given the raw data
   x and y (which are columns of data).  Obviously, any Python functions can be used
   here.  
   
   The return value from this function should be anything that can be translated into
   a numpy array.  If you don't know what this means, don't worry; just follow the
   examples.
   """
   
   B = 0.5
   C = 0.1
   A = 1.5
   A > 0.2 and A < 2.0 and B > 0.2 and B < 2.5 and C < 0.0001 
   
   
   return B,C,A   # return the parameters back to the caller.

