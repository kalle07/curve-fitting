# py3
# this preamble is optional, but it makes things nicer. You can choose the
# name of your model, the equation (if applicable), and the latex form of the equation
# (for nice rendering)

name = r"conrady_new2"
equation = r"a + b/x + c/x^{3.5}"
latexequation = r"a + \frac{b}{x} + \frac{c}{x^{3.5}}"


def evaluate(x, a, b, c):
    """
    The evaluate function determines the function itself. It takes an x value and current parameters
    as an argument, and returns the function evaluation.
    """
    return a + b / x + c / x ** 3.5  # calculate the Inverse Cubic Model


def initialize(x, y):
    """
    The initialize function is in charge of initializing the parameters, given the raw data
    x and y (which are columns of data). Obviously, any Python functions can be used
    here.
    
    The return value from this function should be anything that can be translated into
    a numpy array. If you don't know what this means, don't worry; just follow the
    examples.
    """
    import numpy

    flags = numpy.logical_and(x > 0.0, y > 0.0)
    x = x[flags]
    y = y[flags]

    rss = 1.0e99
    trss = 1.0e99
    n = len(x)
    scale = numpy.arange(0.2, 0.9, 0.2)
    ymax = y.max()
    ymin = y.min()

    for scale0 in scale:
        aa = ymax * 1.1
        bb = aa - scale0 * ymin
        cc = 1.0
        dd = 1.0

        A = numpy.ones((n, 3))
        A[:, 1] = 1.0 / x
        A[:, 2] = 1.0 / x ** 3.5

        B = y - aa - bb / x

        soln, residues, rank, s = lstsq_solve(A, B)

        # now figure out RSS
        c = soln[1]
        d = soln[2]

        residual = evaluate(x, aa, bb, c) - y
        trss = numpy.dot(residual, residual)

        if trss < rss:
            rss = trss
            (a, b, c) = (aa, bb, c)

    return a, b, c  # return the parameters back to the caller.